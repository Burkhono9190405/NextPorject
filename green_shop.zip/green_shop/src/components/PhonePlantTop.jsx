import React from 'react'
import '../styles/phoneplantshop.css'
import arrow from '../images/Arrow - Left 2.png'
function PhonePlantTop() {
  return (
    <div className='PhonePlantTop'>
        <div className="PhonePlantTop1">
        <img src={arrow} alt="" />
        </div>      
       <h1>Cart</h1>
    </div>
  ) 
}

export default PhonePlantTop