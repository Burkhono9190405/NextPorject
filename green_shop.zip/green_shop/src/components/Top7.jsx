import React from 'react'
import '../styles/top7.css'
function Top7() {
  return (
    <div className="Top7">
        <h1>Products</h1>
        <h1>Subtotal</h1>
    </div>
  )
}

export default Top7