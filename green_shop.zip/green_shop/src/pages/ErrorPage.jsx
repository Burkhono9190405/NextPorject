import React from 'react'

function ErrorPage() {
  return (
    <div>This page is not found</div>
  )
}

export default ErrorPage