 import React from 'react'
 import '../styles/top6.css'
 function Top6() {
   return (
     <div className="top6">
       <h1>Our Blog Posts</h1>
       <p>We are an online plant shop offering a wide range of cheap and trendy plants. </p>
     </div>
   )
 }
  
 export default Top6